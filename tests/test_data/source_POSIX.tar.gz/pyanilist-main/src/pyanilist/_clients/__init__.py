from ._async import AsyncAniList
from ._sync import AniList

__all__ = ["AsyncAniList", "AniList"]
