::: pyanilist.AniList
    options:
        members: 
            - __init__
            - search
            - get


::: pyanilist.AsyncAniList
    options:
        members: 
            - __init__
            - search
            - get